prompt --application/pages/page_00003
begin
--   Manifest
--     PAGE: 00003
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>16004677669688678
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DATABOSS'
);
wwv_flow_imp_page.create_page(
 p_id=>3
,p_name=>'Dashboard'
,p_alias=>'DASHBOARD'
,p_step_title=>'Dashboard'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'04'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20250112180018'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18233687035173687)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17920883222696148)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(17805723047696100)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(17982975301696176)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18234215508173687)
,p_plug_name=>'Anomalie Per Anno'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(17908481452696145)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(18234680694173687)
,p_region_id=>wwv_flow_imp.id(18234215508173687)
,p_chart_type=>'line'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(18236382387173687)
,p_chart_id=>wwv_flow_imp.id(18234680694173687)
,p_seq=>10
,p_name=>'Anomalie'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR (A.DATA_ORA, ''YYYY'') AS ANNO, COUNT (*) AS NUMERO_ANOMALIE',
'FROM ANOMALIE A',
'GROUP BY TO_CHAR (A.DATA_ORA, ''YYYY'')',
'ORDER BY 1'))
,p_max_row_count=>20
,p_items_value_column_name=>'NUMERO_ANOMALIE'
,p_items_label_column_name=>'ANNO'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9836324948259627)
,p_chart_id=>wwv_flow_imp.id(18234680694173687)
,p_seq=>20
,p_name=>'Anomalie Irrisolte'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR (A.DATA_ORA, ''YYYY'') AS ANNO, COUNT (*) AS NUMERO_ANOMALIE',
'FROM ANOMALIE A',
'LEFT JOIN STORICO_INTERVENTI ST ON A.ID = ST.ANOMALIA AND A.SENSORE = ST.SENSORE',
'WHERE (ST.ESITO IS NULL OR ST.ESITO <> ''risolto'')',
'GROUP BY TO_CHAR (A.DATA_ORA, ''YYYY'')',
'ORDER BY 1;'))
,p_max_row_count=>20
,p_items_value_column_name=>'NUMERO_ANOMALIE'
,p_items_label_column_name=>'ANNO'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9836279569259626)
,p_chart_id=>wwv_flow_imp.id(18234680694173687)
,p_seq=>30
,p_name=>'Anomalie Risolte'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT TO_CHAR (A.DATA_ORA, ''YYYY'') AS ANNO, COUNT (*) AS NUMERO_ANOMALIE',
'FROM ANOMALIE A',
'JOIN STORICO_INTERVENTI ST ON A.ID = ST.ANOMALIA AND A.SENSORE = ST.SENSORE',
'WHERE ST.ESITO = ''risolto''',
'GROUP BY TO_CHAR (A.DATA_ORA, ''YYYY'')',
'ORDER BY 1;'))
,p_max_row_count=>20
,p_items_value_column_name=>'NUMERO_ANOMALIE'
,p_items_label_column_name=>'ANNO'
,p_line_style=>'solid'
,p_line_type=>'auto'
,p_marker_rendered=>'auto'
,p_marker_shape=>'auto'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>false
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(9834947683259613)
,p_chart_id=>wwv_flow_imp.id(18234680694173687)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(9835034355259614)
,p_chart_id=>wwv_flow_imp.id(18234680694173687)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18236900902173687)
,p_plug_name=>'Rilevazioni Per Tipologia'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(17908481452696145)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(18237313487173689)
,p_region_id=>wwv_flow_imp.id(18236900902173687)
,p_chart_type=>'bar'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_orientation=>'vertical'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_stack=>'off'
,p_connect_nulls=>'Y'
,p_sorting=>'label-asc'
,p_fill_multi_series_gaps=>true
,p_zoom_and_scroll=>'off'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_group_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(18237894582173689)
,p_chart_id=>wwv_flow_imp.id(18237313487173689)
,p_seq=>10
,p_name=>'Numero di Rilevazioni'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT S.TIPO AS TIPO, COUNT (*) AS NUMERO_RILEVAZIONI',
'FROM RILEVAZIONI R',
'JOIN SENSORI S ON R.SENSORE = S.ID',
'GROUP BY S.TIPO;'))
,p_max_row_count=>20
,p_items_value_column_name=>'NUMERO_RILEVAZIONI'
,p_items_label_column_name=>'TIPO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(9835701003259621)
,p_chart_id=>wwv_flow_imp.id(18237313487173689)
,p_seq=>20
,p_name=>'Numero di Sensori'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT S.TIPO, COUNT (*) AS NUMERO_SENSORI',
'FROM SENSORI S',
'GROUP BY S.TIPO;'))
,p_max_row_count=>20
,p_items_value_column_name=>'NUMERO_SENSORI'
,p_items_label_column_name=>'TIPO'
,p_assigned_to_y2=>'off'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(9835549427259619)
,p_chart_id=>wwv_flow_imp.id(18237313487173689)
,p_axis=>'x'
,p_is_rendered=>'on'
,p_format_scaling=>'auto'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
,p_tick_label_rotation=>'auto'
,p_tick_label_position=>'outside'
);
wwv_flow_imp_page.create_jet_chart_axis(
 p_id=>wwv_flow_imp.id(9835668147259620)
,p_chart_id=>wwv_flow_imp.id(18237313487173689)
,p_axis=>'y'
,p_is_rendered=>'on'
,p_format_type=>'decimal'
,p_decimal_places=>0
,p_format_scaling=>'none'
,p_scaling=>'linear'
,p_baseline_scaling=>'zero'
,p_position=>'auto'
,p_major_tick_rendered=>'on'
,p_minor_tick_rendered=>'off'
,p_tick_label_rendered=>'on'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18238420648173689)
,p_plug_name=>unistr('Anomalie per Priorit\00E0')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(17908481452696145)
,p_plug_display_sequence=>30
,p_plug_new_grid_row=>false
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(18238890328173689)
,p_region_id=>wwv_flow_imp.id(18238420648173689)
,p_chart_type=>'donut'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'off'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(18240553554173689)
,p_chart_id=>wwv_flow_imp.id(18238890328173689)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'SELECT A.Livello_Priorita, COUNT (*) AS NUMERO_ANOMALIE',
'FROM ANOMALIE A',
'GROUP BY A.Livello_Priorita',
'ORDER BY 1'))
,p_items_value_column_name=>'NUMERO_ANOMALIE'
,p_items_label_column_name=>'LIVELLO_PRIORITA'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18241119678173689)
,p_plug_name=>'Stato Missioni'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>wwv_flow_imp.id(17908481452696145)
,p_plug_display_sequence=>10
,p_plug_source_type=>'NATIVE_JET_CHART'
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
);
wwv_flow_imp_page.create_jet_chart(
 p_id=>wwv_flow_imp.id(18241574296173689)
,p_region_id=>wwv_flow_imp.id(18241119678173689)
,p_chart_type=>'pie'
,p_height=>'400'
,p_animation_on_display=>'auto'
,p_animation_on_data_change=>'auto'
,p_data_cursor=>'auto'
,p_data_cursor_behavior=>'auto'
,p_hide_and_show_behavior=>'withRescale'
,p_hover_behavior=>'dim'
,p_value_format_type=>'decimal'
,p_value_decimal_places=>0
,p_value_format_scaling=>'none'
,p_tooltip_rendered=>'Y'
,p_show_series_name=>true
,p_show_value=>true
,p_legend_rendered=>'on'
,p_legend_position=>'auto'
,p_pie_other_threshold=>0
,p_pie_selection_effect=>'highlight'
);
wwv_flow_imp_page.create_jet_chart_series(
 p_id=>wwv_flow_imp.id(18243287379173690)
,p_chart_id=>wwv_flow_imp.id(18241574296173689)
,p_seq=>10
,p_name=>'Series 1'
,p_data_source_type=>'SQL'
,p_data_source=>'SELECT * FROM NUM_MISSIONI_PER_STATO'
,p_max_row_count=>20
,p_items_value_column_name=>'NUMERO_MISSIONI'
,p_items_label_column_name=>'STATO_MISSIONE'
,p_items_label_rendered=>true
,p_items_label_position=>'auto'
,p_items_label_display_as=>'LABEL'
);
wwv_flow_imp.component_end;
end;
/
