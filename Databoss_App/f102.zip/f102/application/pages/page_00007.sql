prompt --application/pages/page_00007
begin
--   Manifest
--     PAGE: 00007
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>16004677669688678
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DATABOSS'
);
wwv_flow_imp_page.create_page(
 p_id=>7
,p_name=>'Mappa Lunare'
,p_alias=>'MAPPA-LUNARE'
,p_step_title=>'Mappa Lunare'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>wwv_flow_imp.id(17819071208696114)
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'C'
,p_page_component_map=>'11'
,p_last_updated_by=>'ADMIN'
,p_last_upd_yyyymmddhh24miss=>'20250114001834'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18604427176138615)
,p_plug_name=>'Sensori'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_escape_on_http_output=>'Y'
,p_plug_template=>wwv_flow_imp.id(17908481452696145)
,p_plug_display_sequence=>10
,p_include_in_reg_disp_sel_yn=>'Y'
,p_plug_display_point=>'REGION_POSITION_02'
,p_query_type=>'TABLE'
,p_query_table=>'SENSORI'
,p_include_rowid_column=>false
,p_plug_source_type=>'NATIVE_JQM_LIST_VIEW'
,p_plug_query_num_rows=>15
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_02=>'ID'
,p_attribute_06=>'STATO_OPERATIVO'
,p_attribute_08=>'TIPO'
,p_attribute_16=>'f?p=&APP_ID.:5:&SESSION.::&DEBUG.:::#ID#'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18625603227204326)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17920883222696148)
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_menu_id=>wwv_flow_imp.id(17805723047696100)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>wwv_flow_imp.id(17982975301696176)
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(18626150086204328)
,p_plug_name=>'Map'
,p_region_name=>'id_imm'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>wwv_flow_imp.id(17843890204696125)
,p_plug_display_sequence=>10
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!DOCTYPE html>',
'<html lang="it">',
'<head>',
'    <meta charset="UTF-8">',
'    <meta name="viewport" content="width=device-width, initial-scale=1.0">',
'    <title>Mappa Lunare</title>',
'    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />',
'    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>',
'</head>',
'<body>',
'    <!-- Contenitore della mappa -->',
'    <div id="mapDiv" style="width: 100%; height: 500px;"></div>',
'',
'    <!-- Script inline per configurare la mappa -->',
'    <script>',
'        document.addEventListener("DOMContentLoaded", function () {',
'            var mapDiv = document.getElementById("mapDiv");',
'            if (!mapDiv) {',
'                console.error("Il contenitore della mappa (#mapDiv) non esiste.");',
'                return;',
'            }',
'',
'            var map = L.map("mapDiv", {',
'                center: [0, 0],',
'                zoom: 1,',
'                crs: L.CRS.Simple,',
'                maxBounds: bounds, // Imposta i confini massimi della mappa',
'                maxBoundsViscosity: 1.0, // Rende il limite rigido',
'                minZoom: 2, // Livello di zoom minimo',
'                maxZoom: 5  // Livello di zoom massimo',
'            });',
'',
'            var bounds = [[-90, -180], [90, 180]];',
'            L.imageOverlay("#APP_IMAGES#luna.png", bounds).addTo(map);',
'            map.fitBounds(bounds);',
'',
'            fetch(''http://localhost:8888/ords/progetto/marker/boh'')',
'                .then(response => response.json())',
'                .then(data => {',
'                    data.items.forEach(marker => {',
'                        var popupContent = `',
'                            <strong>Tipo:</strong> ${marker.tipo}<br>',
'                            <strong>ID Marker:</strong> ${marker.marker_id}<br>',
'                            <strong>Latitudine:</strong> ${marker.latitude}<br>',
'                            <strong>Longitudine:</strong> ${marker.longitude}',
'                        `;',
'',
'                        L.marker([marker.latitude, marker.longitude])',
'                            .addTo(map)',
'                            .bindPopup(popupContent);',
'                    });',
'                })',
'                .catch(error => console.error("Errore durante il recupero dei marker:", error));',
'',
'        });',
'    </script>',
'</body>',
'</html>',
'',
''))
,p_plug_query_options=>'DERIVED_REPORT_COLUMNS'
,p_attribute_01=>'N'
,p_attribute_02=>'HTML'
);
wwv_flow_imp.component_end;
end;
/
