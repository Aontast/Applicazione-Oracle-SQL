prompt --application/shared_components/user_interface/lovs/anomalie_causa
begin
--   Manifest
--     ANOMALIE.CAUSA
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>16004677669688678
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DATABOSS'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(18926375675598335)
,p_lov_name=>'ANOMALIE.CAUSA'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_use_local_sync_table=>false
,p_query_table=>'ANOMALIE'
,p_return_column_name=>'ID'
,p_display_column_name=>'CAUSA'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'CAUSA'
,p_default_sort_direction=>'ASC'
);
wwv_flow_imp.component_end;
end;
/
