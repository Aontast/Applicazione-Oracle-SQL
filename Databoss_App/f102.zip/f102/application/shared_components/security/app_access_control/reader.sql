prompt --application/shared_components/security/app_access_control/reader
begin
--   Manifest
--     ACL ROLE: Reader
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2022.10.07'
,p_release=>'22.2.0'
,p_default_workspace_id=>16004677669688678
,p_default_application_id=>102
,p_default_id_offset=>0
,p_default_owner=>'DATABOSS'
);
wwv_flow_imp_shared.create_acl_role(
 p_id=>wwv_flow_imp.id(18011051857696210)
,p_static_id=>'READER'
,p_name=>'Reader'
,p_description=>'Role assigned to application readers.'
);
wwv_flow_imp.component_end;
end;
/
